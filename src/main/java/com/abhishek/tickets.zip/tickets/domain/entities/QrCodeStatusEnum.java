package com.devtiro.tickets.domain.entities;

public enum QrCodeStatusEnum {
  ACTIVE, EXPIRED
}
